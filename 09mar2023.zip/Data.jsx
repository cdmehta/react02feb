import { React } from "react";
class Data extends React.Component {
render(){
    return <h1>This is my Class Component</h1>;
}
}
export default Data;
// module.exports=Data;