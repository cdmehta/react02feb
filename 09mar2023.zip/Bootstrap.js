import React from "react";

export default function  Bootstrap(){
    return <>
        <div className="alert alert-primary" role="alert">
  A simple primary alert—check it out!
</div>
    </>
}