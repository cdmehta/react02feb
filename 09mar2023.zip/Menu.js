import React from "react";

function Menu(props){
    return <h3>{props.item}</h3>;
}
export default Menu;