import React from "react";
import Desc from './Desc';

export default function Events(){
    function callme(){
        
        alert("Function Called");
    }
    return<>
        <Desc/>
        <button className="btn btn-primary" onClick={callme}>Click Me</button>  
    </>;
}