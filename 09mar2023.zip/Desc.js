import React from "react";
import './Desc.css';
import myimg from './images/338596.jpg'
function Desc(props){
    return <><h2><font color={props.val}>This is Description...</font></h2>
    <h3>Demo</h3>
    <img src={myimg} alt=""></img>
    </>
    ;
}
export default Desc;