
import React from 'react';
import ReactDOM from 'react-dom/client';
// import Data from './Data.jsx';
// import Mydata from './Mydata'
// import Desc from './Desc'
// import Menu from './Menu';
// import Image from './Image';
// import Header from './Header';
// import Footer from './Footer';
// import Bootstrap from './Bootstrap';
import Events from './Events';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
  <Events/>
  {/* <Bootstrap/>
  <Header />
  <Image/>
  <Footer year="2022" org="TCS" color="blue"/> */}
   {/* <Desc />
   <Desc />
   <Desc />
   <Desc val="blue" />
   <Menu item="About Us"/>
   <Menu item="Contact Us"/> */}
   
   </>
    // <App />
  
);

