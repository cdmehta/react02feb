import { React } from "react";
function Mydata(){

    return <h1>This is my Class Component</h1>;

}
export default Mydata;
// module.exports=Data;