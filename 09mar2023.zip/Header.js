import React from "react";
import './Header.css';
export default function Header(){
    return <>
        <h1>HEADER</h1>
    </>;
}
// export default Header;