import { React } from "react";
import './Image.css';
import img1 from "./images/338596.jpg";
import img2 from "./images/car.jpg";
function Image(){
    return <>
        <h2 className="heading">My Image</h2>
        {/* <img src="https://picsum.photos/500" alt=""></img> */}
        <div className="flex">
        <div>
            <img src={img1} alt=""></img>
            <h1>Image 1</h1>
        </div>
        <div>
            <img src={img2} alt=""></img>
            <h1>Image 1</h1>
        </div>
        </div>
    </>;
}
export default Image;