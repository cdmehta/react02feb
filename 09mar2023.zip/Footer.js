import React from "react";
export default function Footer(props){
    const clr={color:props.color};
    return <>
        <h4 style={clr}>All rights reserved to {props.org} &copy; {props.year}</h4>
        <h1>{props.color}</h1>
     </>;
}